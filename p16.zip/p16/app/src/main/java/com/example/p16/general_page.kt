package com.example.p16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class general_page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_general_page)
    }

    fun goToPageAddTask(view: View) {
        val intent = Intent(this, add_task_page::class.java);
        startActivity(intent);
    }

    fun goToProfile(view: View) {
        val intent = Intent(this, profile_activity::class.java);
        startActivity(intent);
    }

    fun goToAlarmPage(view: View) {
        val intent = Intent(this, edit_alarm::class.java);
        startActivity(intent)
    }
}