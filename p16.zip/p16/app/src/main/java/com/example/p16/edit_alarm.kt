package com.example.p16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast

class edit_alarm : AppCompatActivity() {
    lateinit var clockField:TextView;
    lateinit var dateField: TextView;

    lateinit var checkboxPn: CheckBox;
    lateinit var checkboxVt: CheckBox;
    lateinit var checkboxSr: CheckBox;
    lateinit var checkboxCh: CheckBox;
    lateinit var checkboxPt: CheckBox;
    lateinit var checkboxSb: CheckBox;
    lateinit var checkboxVs: CheckBox;

    var resultStr = "Поставлен будильник на ";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_alarm)
        clockField = findViewById(R.id.clock_field);
        dateField = findViewById(R.id.data_field);

        checkboxPn = findViewById(R.id.pn);
        checkboxVt = findViewById(R.id.vt);
        checkboxSr = findViewById(R.id.sr);
        checkboxCh = findViewById(R.id.ch);
        checkboxPt = findViewById(R.id.pt);
        checkboxSb = findViewById(R.id.sb);
        checkboxVs = findViewById(R.id.vs);
    }
// isEmbled = true;
    fun backToGeneralPage1(view: View) {
        val intent = Intent(this, general_page::class.java);
        startActivity(intent);

        val toast = Toast.makeText(this, "Будильник добавлен.", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.BOTTOM, 0, 30);
        toast.show();
    }

    fun backToGeneralPage2(view: View) {
        checkboxPn.isChecked = false;
        checkboxVt.isChecked = false;
        checkboxSr.isChecked = false;
        checkboxCh.isChecked = false;
        checkboxPt.isChecked = false;
        checkboxSb.isChecked = false;
        checkboxVs.isChecked = false;

        checkboxPn.isClickable = true;
        checkboxVt.isClickable = true;
        checkboxSr.isClickable = true;
        checkboxCh.isClickable = true;
        checkboxPt.isClickable = true;
        checkboxSb.isClickable = true;
        checkboxVs.isClickable = true;

        resultStr = "Поставлен будильник на ";

    }
    fun showClockDay1(view: View) {
        val toast = Toast.makeText(this, "Будильник на понедельник", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 150, -250);
        toast.show();

        checkboxVt.isClickable = false;
    }
    fun showClockDay2(view: View) {
        val toast = Toast.makeText(this, "Будильник на вторник", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 130, -170);
        toast.show();

        checkboxPn.isClickable = false;
        checkboxSr.isClickable = false;
    }
    fun showClockDay3(view: View) {
        val toast = Toast.makeText(this, "Будильник на среду", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 130, -70);
        toast.show();

        checkboxVt.isClickable = false;
        checkboxCh.isClickable = false;
    }
    fun showClockDay4(view: View) {
        val toast = Toast.makeText(this, "Будильник на четверг", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 130, 30);
        toast.show();

        checkboxSr.isClickable = false;
        checkboxPt.isClickable = false;
    }
    fun showClockDay5(view: View) {
        val toast = Toast.makeText(this, "Будильник на пятницу", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 130, 130);
        toast.show();

        checkboxSb.isClickable = false;
        checkboxCh.isClickable = false;
    }
    fun showClockDay6(view: View) {
        val toast = Toast.makeText(this, "Будильник на субботу", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 130, 200);
        toast.show();

        checkboxPt.isClickable = false;
        checkboxVs.isClickable = false;
    }
    fun showClockDay7(view: View) {
        val toast = Toast.makeText(this, "Будильник на воскресенье", Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 160, 300);
        toast.show();

        checkboxSb.isClickable = false;
    }

    fun addClock(view: View) {
        var resultStr = "Поставлен будильник на ";

        if(checkboxPn.isChecked) {
            resultStr += "\nпонедельник";
        }

        if(checkboxVt.isChecked) {
            resultStr += "\nвторник";
        }

        if(checkboxSr.isChecked) {
            resultStr += "\nсреда";
        }

        if(checkboxCh.isChecked) {
            resultStr += "\nчетверг";
        }

        if(checkboxPt.isChecked) {
            resultStr += "\nпятница";
        }

        if(checkboxSb.isChecked) {
            resultStr += "\nсуббота";
        }

        if(checkboxVs.isChecked) {
            resultStr += "\nвоскресенье";
        }

        resultStr += clockField.text;
        resultStr += dateField.text;

        val toast = Toast.makeText(this, resultStr, Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.BOTTOM, 0, 30);
        toast.show();
    }
}