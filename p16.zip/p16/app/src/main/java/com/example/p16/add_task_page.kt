package com.example.p16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.Toast

class add_task_page : AppCompatActivity() {

    lateinit var taskTitle: EditText;
    lateinit var taskDescription: EditText;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task_page)

        taskTitle = findViewById(R.id.task_title);
        taskDescription = findViewById(R.id.task_description);
    }

    fun backToGeneralPage(view: View) {
        val intent = Intent(this, general_page::class.java);
        startActivity(intent);
    }

    fun addTask(view: View) {
        if (taskTitle.text.toString().isNotEmpty() && taskDescription.text.toString().isNotEmpty()) {
            val toast = Toast.makeText(this, "Задача добавлена", Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.BOTTOM, 0, 30);
            toast.show();

            backToGeneralPage(view);
        } else {
            val alert = AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("У вас есть незаполненные поля")
                .setPositiveButton("Ок", null)
                .create()
                .show()
        }
    }
}